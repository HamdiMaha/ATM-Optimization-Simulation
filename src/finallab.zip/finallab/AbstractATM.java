/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallab;

/**
 *
 * @author scottianderson
 */
public abstract class AbstractATM {
    
    public abstract void setWithdrawLimit(double limit);
    public abstract void setMalfunctionProbability(int prob);
    public abstract void setCostOfATM(int cost);
    public abstract void setCostOfTransaction(double cost);
    public abstract void setCashLoad(double load);
    
    public abstract boolean withdraw(int amount);
    public abstract void refill();
    
}
