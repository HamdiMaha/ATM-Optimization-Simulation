/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallab;

/**
 *
 * @author scottianderson
 */
public class UseATMEvent extends AbstractEvent {

    public UseATMEvent(int time, Customer customer) {
        super(time, customer);
    }

    @Override
    void simulation(Controller c) {
        EventQueue events = c.getEvents();
        events.add(new DepartureEvent(time + customer.transaction_time(), customer));
    }
    
}
