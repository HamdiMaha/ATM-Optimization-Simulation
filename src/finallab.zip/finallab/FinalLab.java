/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallab;

import java.util.*;

/**
 *
 * @author scottianderson
 */
public class FinalLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new ControlFrame();
        GraphFrame gF = new GraphFrame();
        ArrayList<Double> aL = new ArrayList<>();
        aL.add(2.1);
        aL.add(3.5);
        aL.add(0.9);
        gF.graph("Data", aL);
    }
    
}
