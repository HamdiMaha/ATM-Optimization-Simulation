/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallab;

/**
 *
 * @author hamdi
 */
class ATM extends AbstractATM {
    private int ATM_Cost;
    private int malfunction;
    private double machine_cash;
    private double transaction_cost;
    private double withdrawn_limit;
    
    private double cash_left = machine_cash;
    

    public int getATM_Cost() {
       return ATM_Cost;
    }
    @Override
    public void setCostOfATM(int ATM_Cost ) {
       this.ATM_Cost = ATM_Cost;
    }
    public double machine_cash() {
       return machine_cash;
    }
    @Override
    public void setCashLoad(double machine_cash ) {
       this.machine_cash = machine_cash;
    }
    public double gettransaction_cost() {
       return transaction_cost;
    }
    @Override
    public void setCostOfTransaction(double transaction_cost ) {
       this.transaction_cost = transaction_cost;
    }
    public double getwithdrawn_limit() {
       return withdrawn_limit;
    }
    @Override
    public void setWithdrawLimit(double withdrawn_limit ) {
       this.withdrawn_limit = withdrawn_limit;
    }
    public int getmalfunction() {
       return malfunction;
    }
    @Override
    public void setMalfunctionProbability(int malfunction ) {
       this.malfunction = malfunction;
    }
   
  
    
    @Override
    public boolean withdraw(int amount){
        if (amount > machine_cash || amount > withdrawn_limit)
            return false;
        else{
            cash_left = machine_cash - amount;
            return true;
        }
            
        
    }
    @Override
    public  void refill(){
       
        cash_left = machine_cash;
            
    }


}
