/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallab;

import java.util.*;
import javax.swing.JPanel;

/**
 *
 * @author scottianderson
 */
public class Controller extends AbstractController{
    
    private ATM_list atms;
    private int avgTransactionLength;
    private int avgPatience;
    private int avgNumber;
    
    private EventQueue events;
    private CustomerQueue line;
    private ArrayList<Double> waitTimeList;
    
    public Controller(JPanel panel) {
        super(panel);
        atms = new ATM_list();
        events = new EventQueue();
        line = new CustomerQueue();
        waitTimeList = new ArrayList<>();
    }
    
    @Override
    public void addATM(AbstractATM atm) {
        atms.add(atm);
    }

    @Override
    public void setAvgTransactionLength(int length) {
        avgTransactionLength = length;
    }

    @Override
    public void setAvgPatience(int avgPatience) {
        this.avgPatience = avgPatience;
    }

    @Override
    public void setAvgNumber(int avgNumber) {
        this.avgNumber = avgNumber;
    }

    public EventQueue getEvents() {
        return events;
    }

    public CustomerQueue getLine() {
        return line;
    }

    @Override
    public void run(int numDays) {
        for (int i = 0; i < numDays; i++) {
            /// Create list of customers
            
                /// Generate time of day / length of transaction / withdraw amount
                /// Push customers into event queue for arrival
            Customer_list customers = new Customer_list();
            customers.add(new Customer(890, 893));
            customers.add(new Customer(892, 895));
            customers.add(new Customer(893, 895));
            customers.add(new Customer(895, 899));
            customers.add(new Customer(895, 899));
            customers.add(new Customer(900, 905));
            
            for (Customer c : customers) {
                events.add(new ArrivalEvent(c.getarrival_time(), c));
            }
            
            /// Calculate time spent
            
            while (!events.isEmpty()) {
                AbstractEvent e = events.poll();
                e.simulation(this);
                
                if (e instanceof DepartureEvent) {
                    waitTimeList.add((double) e.time - e.getCustomer().getarrival_time() - e.getCustomer().transaction_time());
                }
            }
            
            System.out.println(waitTimeList);
            
                // while there events in the queue
                    // pop event
        }
    }

    @Override
    public void reset() {
        atms = new ATM_list();
    }
    
}
